#!/usr/bin/env python
# coding: utf-8

# preprocess train & test data

# In[6]:


from tqdm import tqdm

def datacombine():
        

    
    file2=open("train.de",encoding='utf-8')
    file1=open('train.en')
    
    file_list1=[]
    #file_list1=file1.readlines()
    for line in file1.readlines():
        file_list1.append(line.strip('\n'))
    file_list2=file2.readlines()

    file_list3=[]
    for i in tqdm(range(len(file_list1))):
        s='\t'.join([str(file_list1[i]) ,str(file_list2[i])])
        #s+='\n'
        file_list3.append(s)
    file3=open("dirdata","w",encoding='utf-8')
    file3.writelines(file_list3)
    file1.close()
    file2.close()
    file3.close()  
    

    file1=open("test_2016_flickr.de",encoding='utf-8')
    file2=open('test_2016_flickr.en')   
    file_list1=[]
    #file_list1=file1.readlines()
    for line in file1.readlines():
        file_list1.append(line.strip('\n'))
    file_list2=file2.readlines()

    file_list3=[]
    for j in tqdm(range(14500)):
        s='\t'.join([str(file_list1[j]) ,str(file_list2[j])])
        #s+='\n'
        file_list3.append(s)
    file3=open("TheData","w",encoding='utf-8')
    file3.writelines(file_list3)
    file1.close()
    file2.close()
    file3.close()  
        
datacombine()

