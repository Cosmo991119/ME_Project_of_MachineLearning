# README

## About virtual environment

we use ubuntu 18.04 to run the code, and use the pytorch.

##### 1.1 get ubuntu+pytorch

https://zhuanlan.zhihu.com/p/78075698

##### 1.2 download  cudnn with the documents be provide by  nvidia 

https://docs.nvidia.com/deeplearning/cudnn/install-guide/index.html#install-windows

##### 2.  how to run the code

this for onelyar_indire.py

`source PytorchVenv/bin/activate`

`ipython`

`import pytorch`

`torch.cuda.is_available()`

`exit()`

`cd <model dir>`

`python3 <model name>.py`









